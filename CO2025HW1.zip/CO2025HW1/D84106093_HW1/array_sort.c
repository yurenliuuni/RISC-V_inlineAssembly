#include <stdio.h>

int main(int argc, char *argv[])
{
    if (argc < 2) {
        printf("Usage: %s <input_file>\n", argv[0]);
        return 1;
    }

    FILE *input = fopen(argv[1], "r");
    if (!input) {
        fprintf(stderr, "Error opening file: %s\n", argv[1]);
        return 1;
    }
    int arr_size;
    fscanf(input, "%d", &arr_size);
    int arr[arr_size];

    // Read integers from input file into the array
    for (int i = 0; i < arr_size; i++) {
        int data;
        fscanf(input, "%d", &data);
        arr[i] = data;
    }
    fclose(input);

    int *p_a = &arr[0];

    // array a bubble sort
    /* Original C code segment
    for (int i = 0; i < arr_size - 1; i++) {
        for (int j = 0; j < arr_size - i -1; j++) {
            if (*(p_a + j) > *(p_a + j + 1)) {
                int tmp = *(p_a + j);
                *(p_a + j) = *(p_a + j + 1);
                *(p_a + j + 1) = tmp;
            }
        }
    }
    */

    for (int i = 0; i < arr_size - 1; i++) {
        for (int j = 0; j < arr_size - i - 1; j++) {
            asm volatile(
            "addi sp, sp, -16       \n"  // maintain 16-byte stack alignment in riscv
            "sw   x18, 0(sp)        \n"  // 
            "sw   x19, 4(sp)        \n"
            "sw   x20, 8(sp)        \n"
            
            // address of pa+j
            "slli x18, %[j], 2      \n"  // j * 4 (byte-addressing)
            "add  x18, %[pa], x18   \n"  
            
            // load pa[j] and pa[j+1]
            "lw   x19, 0(x18)        \n" 
            "lw   x20, 4(x18)        \n"  
            
            // conditionally swap
            "ble  x19, x20, Exit      \n"  
            "sw   x20, 0(x18)        \n"  
            "sw   x19, 4(x18)        \n"
            
            "Exit:                    \n"  // Label for skip
            "lw   x20, 8(sp)        \n"  // Restore registers
            "lw   x19, 4(sp)        \n"
            "lw   x18, 0(sp)        \n"
            "addi sp, sp, 16       \n"
            : 
            : [pa] "r" (p_a), [j] "r" (j)
            : "x18", "x19", "x20"
                );
        }
    }
    p_a = &arr[0];
    for (int i = 0; i < arr_size; i++)
        printf("%d ", *p_a++);
    printf("\n");
    return 0;
}
